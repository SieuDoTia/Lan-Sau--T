/* WIND.h */
/* 2017.08.30 */


#include <stdio.h>
#include <stdlib.h>
#include "WIND.h"


WIND docWIND( unsigned char *duLieu, short id ) {
   
   WIND taiNguyenWIND;
   taiNguyenWIND.id = id;
   
   taiNguyenWIND.top = *duLieu << 8 | *(duLieu++);
   taiNguyenWIND.left = *(duLieu++) << 8 | *(duLieu++);
   taiNguyenWIND.bottom = *(duLieu++) << 8 | *(duLieu++);
   taiNguyenWIND.right = *(duLieu++) << 8 | *(duLieu++);
   
   taiNguyenWIND.definitionID = *(duLieu++) << 8 | *(duLieu++);
   taiNguyenWIND.visibilityStatus = *(duLieu++) << 8 | *(duLieu++);
   taiNguyenWIND.closeBox = *(duLieu++) << 8 | *(duLieu++);
   taiNguyenWIND.referenceConst = *(duLieu++) << 8 | *(duLieu++);
   
   // ---- title
   taiNguyenWIND.titleLength = *(duLieu++);
   unsigned chiSo = 0;
   while( chiSo <= taiNguyenWIND.titleLength ) {
      taiNguyenWIND.title[chiSo] = *(duLieu++);
      chiSo++;
   }
   taiNguyenWIND.title[chiSo] = 0x00;
   
   //   taiNguyenWIND.position = *(duLieu++) << 8 | *(duLieu++);
   
   return taiNguyenWIND;
}

void chieuThongTin_WIND( WIND *taiNguyenWIND ) {
   
   printf( "'WIND'  %s\n", taiNguyenWIND->title );
   printf( "   Rect: %d %d %d %d\n",
          taiNguyenWIND->top,
          taiNguyenWIND->left,
          taiNguyenWIND->bottom,
          taiNguyenWIND->right );
   
   printf( "   definitionID: %d  close box: %d  reference const: %d\n",
          taiNguyenWIND->definitionID,
          taiNguyenWIND->closeBox,
          taiNguyenWIND->referenceConst );
}
