/* WIND.h */
/* 2017.08.30 */


#pragma once

#define kWIND 0x57494e44

/* 'WIND' */
typedef struct {
   short id;
   
   short top;
   short left;
   short bottom;
   short right;
   
   short definitionID;    // loại cửa số
   unsigned short visibilityStatus;
   unsigned short closeBox;
   unsigned int referenceConst;
   unsigned char titleLength;
   char title[257];      // cho tựa dài 256 ký tự và ký tựa kết thúc
   short position;
} WIND;


WIND docWIND( unsigned char *duLieu, short id );
void chieuThongTin_WIND( WIND *taiNguyenWIND );
