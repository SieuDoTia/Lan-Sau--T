/* vers.h */
/* 2018.04.07 */


#pragma once

#define kvers 0x76657273

/* 'vers' */
typedef struct {
   short id;
   
   // 2 byte: 0xXXYZ  --> XX.Y.Z
   unsigned char soPhienBan_soNguyen;  // X: btye đầu
   unsigned char soPhienBan_soThapPhan;  // Y:  4 bit cao của byte cuối
   unsigned char soPhienBan_soTramPhan;  // Z:  4 bit thấp của byte cuối

   // Qúa trình có 4 giá trị:
   //     0x20 - phát triển
   //     0x40 - alpha
   //     0x60 - bets
   //     0x80 - phát hành
   unsigned char phatHanh;  // phát hành
   unsigned char khongPhatHanh;  // không phát hành
   
   unsigned quocGia;   // quốc gia
   
   unsigned char beDaiXauNgan;  // bề dài ngắn
   unsigned char xauNgan[256];  // xâu ngắn
   
   unsigned char beDaiXauDai;   // bề dài xâu dài
   unsigned char xauDai[256];   // xâu dài
} vers;


vers doc_vers( unsigned char *duLieu, short id );
void chieuThongTin_vers( vers *taiNguyen_vers );
