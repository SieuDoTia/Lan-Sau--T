/* CODE.h */
/* 2017.08.30 */

/* 'CODE' */
/* Bảng nhảy thường ở trong tài nguyên 'CODE' mã số 0 (từ sách Inside Mactintosh: Processes) */

#pragma once

#define kCODE 0x434f4445

typedef struct {
   short id;
   
   
} CODE;

/* Bảg Nhảy */ 
typedef struct {
   unsigned int kichCoTrenA5;
   unsigned int kichCoBienToanCau;
   unsigned int beDai;  // byte
   unsigned int dichTuA5;
   
   unsigned int soLuongO;
   unsigned short *mangDichTuDau;
   unsigned long int *mangMaNguonThucHanh; // thực chỉ dùng 6 byte
} BangNhay;


BangNhay docBangNhay( unsigned char *duLieu );
void chieuThongTinBangNhay( BangNhay *bangNhay );
