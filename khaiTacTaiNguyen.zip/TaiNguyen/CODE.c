/* CODE.h */
/* 2017.08.30 */

/* 'CODE' */
/* Bảng nhảy thường ở trong tài nguyên 'CODE' mã số 0 (từ sách Inside Mactintosh: Processes) */

#include <stdio.h>
#include <stdlib.h>
#include "CODE.h"


BangNhay docBangNhay( unsigned char *duLieu ) {
   
   BangNhay bangNhay;

   bangNhay.kichCoTrenA5 = *(duLieu++) << 24 | *(duLieu++) << 16 | *(duLieu++) << 8 | *(duLieu++);
   bangNhay.kichCoBienToanCau = *(duLieu++) << 24 | *(duLieu++) << 16 | *(duLieu++) << 8 | *(duLieu++);
   bangNhay.beDai = *(duLieu++) << 24 | *(duLieu++) << 16 | *(duLieu++) << 8 | *(duLieu++);
   bangNhay.dichTuA5 = *(duLieu++) << 24 | *(duLieu++) << 16 | *(duLieu++) << 8 | *(duLieu++);

   // ---- bảng
   bangNhay.soLuongO = bangNhay.beDai >> 3;
   bangNhay.mangDichTuDau = malloc( bangNhay.soLuongO << 1 );
   bangNhay.mangMaNguonThucHanh = malloc( bangNhay.soLuongO << 3 );

   
   unsigned int soO = 0;
   while( soO < bangNhay.soLuongO ) {
      // ---- địch
      bangNhay.mangDichTuDau[soO] = *(duLieu++) << 8 | *(duLieu++);
      
      // ---- mã nguồn
      unsigned long int phanTren = *(duLieu++) << 8 | *(duLieu++);
      unsigned long int phanDuoi = *(duLieu++) << 24 | *(duLieu++) << 16 |
      *(duLieu++) << 8 | *(duLieu++);
      bangNhay.mangMaNguonThucHanh[soO] = phanTren << 32 | phanDuoi;
 
      soO++;
   }
   
   return bangNhay;
}

void chieuThongTinBangNhay( BangNhay *bangNhay ) {
  
   // ---- thông tin tồng quát
   printf( "  Bảng nhảy: %d\n", bangNhay->kichCoTrenA5 );
   printf( "    Kích cỡ trên A5: %d\n", bangNhay->kichCoTrenA5 );
   printf( "    Kích cỡ biến toàn cầu: %d\n", bangNhay->kichCoBienToanCau );
   printf( "    Bề dài bảng nhảy (byte): %d\n", bangNhay->beDai );
   printf( "    Dịch từ A5 đến bảng nhảy: %d\n", bangNhay->dichTuA5 );

   // ---- thông tin dịch và mã nguồn bảng nhảy
   printf( "    Dịch từ đầu:    Mã Nguồn (68k hay PPC):\n" );

   unsigned int soO = 0;
   while( soO < bangNhay->soLuongO ) {
      printf( "   %4d   %6d          ", soO, bangNhay->mangDichTuDau[soO] );
      unsigned long int maNguon = bangNhay->mangMaNguonThucHanh[soO];
      printf( "   %02x %02x %02x %02x %02x %02x\n",
             (maNguon >> 40) & 0xff, (maNguon >> 32 ) & 0xff,
             (maNguon >> 24) & 0xff, (maNguon >> 16) & 0xff,
             (maNguon >> 8) & 0xff, maNguon & 0xff );
      soO++;
   }

}

