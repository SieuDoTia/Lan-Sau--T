/* Curv.h */
/* 2017.09.04 */


#include <stdio.h>
#include <stdlib.h>
#include "PICT.h"

unsigned char *giaiMaRLETaoChar( unsigned char *duLieu, ColorTable *bangMau, unsigned short beRongAnh, unsigned short beCaoAnh ) {
   
   printf( "beRongAnh %d  beCaoAnh %d\n", beRongAnh, beCaoAnh );
   unsigned short cot = 0;
   unsigned short hang = 0;
   unsigned char *anh = malloc( beRongAnh * beCaoAnh << 2 );
   
   if( anh ) {
      
      while( hang < beCaoAnh ) {
         printf( "%2d: ", hang );
         
         // ---- số lượng byte cho hàng, ≤ 127
         unsigned char soLuongByteChoHang = *(duLieu++);
         unsigned char soByteDuocXuLy = 0;
         
         while( soByteDuocXuLy < soLuongByteChoHang ) {
            unsigned char byte = *(duLieu++);
            if( byte < 128 ) {  // chép byte + 1 lần
               byte++;
               unsigned char chiSo = 0;
               while( chiSo < byte ) {
                  unsigned char diemAnh = *(duLieu++);
                  printf( "%02x ", diemAnh );
                  chiSo++;
               }
               soByteDuocXuLy += byte + 1;
            }
            else if( byte > 128 ) {
               byte++;
               unsigned char soLuongChep = (255 - byte) + 3;
               
               unsigned char diemAnh = *(duLieu++);
               unsigned char chiSo = 0;
               while( chiSo < soLuongChep ) {
                  printf( "%02x ", diemAnh );
                  chiSo++;
               }
               soByteDuocXuLy += 2;
            }
            
         }
         printf( "\n" );
         hang++;
         
      }
      return anh;
   }
   else {
      printf( "PICT: sai lầm: không thể tạo ảnh\n" );
      return NULL;
   }
   
}

unsigned char *giaiMaRLETaoShort( unsigned char *duLieu, ColorTable *bangMau, unsigned short beRongAnh, unsigned short beCaoAnh ) {
   
   unsigned short cot = 0;
   unsigned short hang = 0;
   unsigned char *anh = malloc( beRongAnh * beCaoAnh << 2 );
   
   if( anh ) {
      
      while( hang < beCaoAnh ) {
         printf( "%2d: ", hang );
         
         // ---- số lượng byte cho hàng, ≤ 32767
         unsigned short soLuongByteChoHang = *(duLieu++) << 8 | *(duLieu++);
         unsigned short soByteDuocXuLy = 0;
         
         while( soByteDuocXuLy < soLuongByteChoHang ) {
            unsigned char byte = *(duLieu++);
            if( byte < 128 ) {  // chép byte + 1 lần
               byte++;
               unsigned char chiSo = 0;
               while( chiSo < byte ) {
                  unsigned char diemAnh = *(duLieu++);
                  printf( "0x%02x ", diemAnh );
                  chiSo++;
               }
               soByteDuocXuLy += byte + 1;
            }
            else if( byte > 128 ) {
               byte++;
               unsigned char soLuongChep = (255 - byte) + 3;
               
               unsigned char diemAnh = *(duLieu++);
               unsigned char chiSo = 0;
               while( chiSo < soLuongChep ) {
                  printf( "0x%02x ", diemAnh );
                  chiSo++;
               }
               soByteDuocXuLy += 2;
            }
            
         }
         printf( "\n" );
         hang++;
         
      }
      return anh;
   }
   else {
      printf( "PICT: sai lầm: không thể tạo ảnh\n" );
      return NULL;
   }
}


PICT docPICT( unsigned char *duLieu ) {
   
   PICT taiNguyenPICT;
   
   taiNguyenPICT.beDaiDuLieu = *(duLieu++) << 8 | *(duLieu++);
   taiNguyenPICT.frameTop = *(duLieu++) << 8 | *(duLieu++);
   taiNguyenPICT.frameLeft = *(duLieu++) << 8 | *(duLieu++);
   taiNguyenPICT.frameBottom = *(duLieu++) << 8 | *(duLieu++);
   taiNguyenPICT.frameRight = *(duLieu++) << 8 | *(duLieu++);
   taiNguyenPICT.phienBan_phan0 = *(duLieu++) << 8 | *(duLieu++);
   
   // ---- phiên bản PICT 1
   if( taiNguyenPICT.phienBan_phan0 == 0x1101 ) {
      
      // ---- đọc mã lệnh
      unsigned char maLenh = 0x00;
      
      while ( maLenh != 0xff ) {
         maLenh = *(duLieu++);
         if( maLenh == 0x00 )
            ;
         else if( maLenh == 0xa0 ) {
            duLieu += 2;
         }
         else if( maLenh == 0xff )
            ;
         else {
            unsigned short beDai = *(duLieu++) << 8 | *(duLieu++);
            duLieu += beDai - 2;
         }
      }
      
   }
   // ---- phiên bản PICT 2
   else if( taiNguyenPICT.phienBan_phan0 == 0x0011 ) {
      
      taiNguyenPICT.phienBan_phan1 = *(duLieu++) << 8 | *(duLieu++);  // nên = 0x02ff
      
      // ---- đọc mã lệnh
      taiNguyenPICT.maLenhDau = *(duLieu++) << 8 | *(duLieu++);  // nên = 0x02ff
      
      // ---- nhảy qua dữ liệu bị hãng Táo giành lại
      duLieu += 34;
      
      taiNguyenPICT.rowBytes = *(duLieu++) << 8 | *(duLieu++);
      unsigned short pixMapCode = *(duLieu++) << 8 | *(duLieu++);
      if( pixMapCode == 0x0098 ) {
         unsigned short colorPixMap = *(duLieu++) << 8 | *(duLieu++);
         if( colorPixMap & 0x8000 )
            taiNguyenPICT.colorPixMap = 0x1;
         
         duLieu += 44;
         
         // ==== bảng màu
         taiNguyenPICT.colorTable.ctSeed = *(duLieu++) << 24 | *(duLieu++) << 16 | *(duLieu++) << 8 | *(duLieu++);
         // ----
         taiNguyenPICT.colorTable.ctFlags = *(duLieu++) << 8 | *(duLieu++);
         unsigned short ctSize = *(duLieu++) << 8 | *(duLieu++);
         ctSize++;  // cộng một
         taiNguyenPICT.colorTable.ctSize = ctSize;
         taiNguyenPICT.colorTable.colorArray = malloc( sizeof( ColorTableColor )*ctSize );
         if( taiNguyenPICT.colorTable.colorArray != NULL ) {
            unsigned short chiSoMau = 0;
            
            while( chiSoMau < ctSize ) {
               // ---- chỉ số màu trong bảng màu
               unsigned short chiSoBangMau = *(duLieu++) << 8 | *(duLieu++);
               // ---- màu
               taiNguyenPICT.colorTable.colorArray[chiSoBangMau].red = *(duLieu++) << 8 | *(duLieu++);
               taiNguyenPICT.colorTable.colorArray[chiSoBangMau].green = *(duLieu++) << 8 | *(duLieu++);
               taiNguyenPICT.colorTable.colorArray[chiSoBangMau].blue = *(duLieu++) << 8 | *(duLieu++);
               chiSoMau++;
            }
            
            taiNguyenPICT.srcRectTop = *(duLieu++) << 8 | *(duLieu++);
            taiNguyenPICT.srcRectLeft = *(duLieu++) << 8 | *(duLieu++);
            taiNguyenPICT.srcRectBottom = *(duLieu++) << 8 | *(duLieu++);
            taiNguyenPICT.srcRectRight = *(duLieu++) << 8 | *(duLieu++);
            
            taiNguyenPICT.dstRectTop = *(duLieu++) << 8 | *(duLieu++);
            taiNguyenPICT.dstRectLeft = *(duLieu++) << 8 | *(duLieu++);
            taiNguyenPICT.dstRectBottom = *(duLieu++) << 8 | *(duLieu++);
            taiNguyenPICT.dstRectRight = *(duLieu++) << 8 | *(duLieu++);
            
            taiNguyenPICT.srcCopy = *(duLieu++) << 8 | *(duLieu++);
            
            // ==== ảnh
            if( taiNguyenPICT.rowBytes > 250)
               taiNguyenPICT.anh = giaiMaRLETaoShort( duLieu, &(taiNguyenPICT.colorTable),
                                                     taiNguyenPICT.frameRight - taiNguyenPICT.frameLeft,
                                                     taiNguyenPICT.frameBottom - taiNguyenPICT.frameTop );
            else
               taiNguyenPICT.anh = giaiMaRLETaoChar( duLieu, &(taiNguyenPICT.colorTable),
                                                    taiNguyenPICT.frameRight - taiNguyenPICT.frameLeft,
                                                    taiNguyenPICT.frameBottom - taiNguyenPICT.frameTop );
         }
         else {
            printf( "PICT: sai lầm tạo bảng màu\n");
            taiNguyenPICT.colorTable.ctSize = 0;
         }
      }
      else {
         printf( "PICT: sai lầm, không phải là pixMap\n" );
      }
      
      /*      taiNguyenPICT.picSize.size = *(duLieu++) << 8 | *(duLieu++);
       taiNguyenPICT.picSize.top = *(duLieu++) << 8 | *(duLieu++);
       taiNguyenPICT.picSize.left = *(duLieu++) << 8 | *(duLieu++);
       taiNguyenPICT.picSize.bottom = *(duLieu++) << 8 | *(duLieu++);
       taiNguyenPICT.picSize.right = *(duLieu++) << 8 | *(duLieu++); */
      
   }
   else {
      printf( "PICT: sai lầm phiên bản\n" );
   }
   
   // ----
   
   return taiNguyenPICT;
}

void chieuThongTin_PICT( PICT *taiNguyenPICT ) {
   
   printf( "'PICT'\n   bề dài: %d\n", taiNguyenPICT->beDaiDuLieu );
   printf( "   frame: %d %d %d %d\n",
          taiNguyenPICT->frameTop,
          taiNguyenPICT->frameLeft,
          taiNguyenPICT->frameBottom,
          taiNguyenPICT->frameRight );
   if( taiNguyenPICT->phienBan_phan0 == 0x1101 ) {
      printf( "   Phiên bản: 1\n" );
   }
   else {
      printf( "   Phiên bản: 2\n" );
      /*       printf( "   Size: %d\n", taiNguyenPICT->picSize.size );
       printf( "       %d  %d  %d  %d\n",
       taiNguyenPICT->picSize.top,
       taiNguyenPICT->picSize.left,
       taiNguyenPICT->picSize.bottom,
       taiNguyenPICT->picSize.right ); */
      printf( "   rowBytes: %d\n", taiNguyenPICT->rowBytes );
      if( taiNguyenPICT->colorPixMap )
         printf( "   colorPixMap\n" );
      printf( "   Color table:\n     ctSeed: 0x%08x  transIndex: %x  ctSize %d\n",
             taiNguyenPICT->colorTable.ctSeed,
             taiNguyenPICT->colorTable.ctFlags,
             taiNguyenPICT->colorTable.ctSize );
      /*      if( taiNguyenPICT->colorTable.ctSize > 0 ) {
       unsigned short chiSoMau = 0;
       while( chiSoMau < taiNguyenPICT->colorTable.ctSize ) {
       printf( "      %d  %04x %04x %04x\n", chiSoMau,
       taiNguyenPICT->colorTable.colorArray[chiSoMau].red,
       taiNguyenPICT->colorTable.colorArray[chiSoMau].green,
       taiNguyenPICT->colorTable.colorArray[chiSoMau].blue
       );
       chiSoMau++;
       }
       } */
      
   }
   printf( "\n\n" );
}

void freePICT( PICT *taiNguyenPICT ) {
   
   taiNguyenPICT->beDaiDuLieu = 0;
   taiNguyenPICT->frameTop = 0;
   taiNguyenPICT->frameLeft = 0;
   taiNguyenPICT->frameBottom = 0;
   taiNguyenPICT->frameRight = 0;
   
   taiNguyenPICT->colorTable.ctSize = 0;
   free( taiNguyenPICT->colorTable.colorArray );
   
   free( taiNguyenPICT->anh );
}

