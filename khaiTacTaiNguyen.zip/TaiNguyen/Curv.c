/* Curv.h */
/* 2017.09.01 */


#include <stdio.h>
#include <stdlib.h>
#include "Curv.h"


Curv docCurv( unsigned char *duLieu, unsigned int beDai ) {
   
   Curv taiNguyenCurv;
   unsigned int soByteThucHanh = 0;
   // ---- không biết 28 byte đều làm gì, có lẽ là mặt nạ
   duLieu += 28;
   soByteThucHanh += 28;

   
   // ---- chưa biết cái này
   taiNguyenCurv.soLuongSICN = 0;
   
   // ---- đọc một bó mặt nạ
   while( soByteThucHanh < beDai ) {
      // ---- bắt đầu SICN (4 byte), có lẽ là mặt nạ (4 byte)
      duLieu += 8;
      soByteThucHanh += 8;
   
      BoMatNa *mangBoMatNa = &(taiNguyenCurv.mangBoMatNa[taiNguyenCurv.soLuongSICN]);
      mangBoMatNa->soLuong = *(duLieu++) << 8 | *(duLieu++);
      mangBoMatNa->mangMatNa = malloc( sizeof( MangMatNa )*mangBoMatNa->soLuong );
      soByteThucHanh += 2;

      // ---- đọc mảng mặt nạ cho bó
      unsigned char chiSoBo = 0;
      while( chiSoBo <  mangBoMatNa->soLuong ) {

         MangMatNa *mangMatNa = &(mangBoMatNa->mangMatNa[chiSoBo]);
         // ---- số lượng khúc trong bó
         mangMatNa->soLuong = *(duLieu++) << 8 | *(duLieu++);
         soByteThucHanh += 2;

         unsigned char chiSoKhuc = 0;
         while( chiSoKhuc < mangMatNa->soLuong ) {
            MatNaKhuc *mangMatNaKhuc = &(mangMatNa->matNa[chiSoKhuc]);
            // ---- mã 'Cu"
            duLieu += 2;
            mangMatNaKhuc->maSo = *(duLieu++) << 8 | *(duLieu++);
            mangMatNaKhuc->matNa0 = *(duLieu++) << 24 | *(duLieu++) << 16 | *(duLieu++) << 8 | *(duLieu++);
            mangMatNaKhuc->matNa1 = *(duLieu++) << 24 | *(duLieu++) << 16 | *(duLieu++) << 8 | *(duLieu++);
            soByteThucHanh += 12;

            chiSoKhuc++;
         }

         chiSoBo++;
      }
      printf( "\n" );
      
      // ---- xong rồi đếm một cái nữa
      taiNguyenCurv.soLuongSICN++;
      
   }
   
   return taiNguyenCurv;
}

void chieuThongTin_Curv( Curv *taiNguyenCurv ) {
   
   printf( "'Curv'\n    Số lương bó khúc %d\n", taiNguyenCurv->soLuongSICN );
   unsigned char chiSo = 0;

   while( chiSo < taiNguyenCurv->soLuongSICN ) {
      
      BoMatNa *mangBoMatNa = &(taiNguyenCurv->mangBoMatNa[chiSo]);
      printf( "      Số lượng khúc trong bó: %d\n", mangBoMatNa->soLuong );

      // ---- đọc mảng mặt nạ cho bó
      unsigned char chiSoBo = 0;
      while( chiSoBo <  mangBoMatNa->soLuong ) {
         
         MangMatNa *mangMatNa = &(mangBoMatNa->mangMatNa[chiSoBo]);
         // ---- số lượng khúc trong bó
         printf( "      Số lượng mặt nạ %d\n", mangMatNa->soLuong );
         
         unsigned char chiSoKhuc = 0;
         while( chiSoKhuc < mangMatNa->soLuong ) {
            MatNaKhuc *mangMatNaKhuc = &(mangMatNa->matNa[chiSoKhuc]);

            printf( "       mã số: %d   mặt nạ %08x %08x\n", mangMatNaKhuc->maSo, mangMatNaKhuc->matNa0, mangMatNaKhuc->matNa1 );
            
            chiSoKhuc++;
         }

         chiSoBo++;
      }
   
      printf( "\n" );
      
      chiSo++;
      
   }
}
