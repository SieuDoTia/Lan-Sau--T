/* PICT.h */
/* 2017.09.04 */

#pragma once

#define kPICT 0x50494354

/*
typedef struct {
    unsigned short size;
    short top;
    short left;
    short bottom;
    short right;
} PicSize;

typedef struct {
    unsigned short version;
    unsigned short pictureVersion;
    unsigned short reservedHeaderOpcode;
    unsigned short headerOpcode;
    unsigned short pictureSize;
    unsigned short horizonalResolution;
    unsigned short verticalResolution;
    short left;
    short top;
    short right;
    short bottom;
} PicFrame;
*/

typedef struct {
   unsigned short red;
   unsigned short green;
   unsigned short blue;
} ColorTableColor;

typedef struct {
   unsigned int ctSeed;
   unsigned short ctFlags;
   unsigned short ctSize;
   ColorTableColor *colorArray;
} ColorTable;

typedef struct {
   // ---- chữ nhật ảnh
   unsigned short beDaiDuLieu;     // bề dài dữ liệu
   unsigned short frameTop;     // khung trên
   unsigned short frameLeft;    // khung trái
   unsigned short frameBottom;  // khung dưới
   unsigned short frameRight;   // khung phải
   
   // ---- Ảnh PICT có hai phiên bản 1 và 2,
   //      Phiên bản 1 chí hổ trợ ảnh trắng đen, mã lệnh một byte
   //      Phiên bản 2 hỗ trợ ảnh màu mã lệnh hai byte
   //      Thông tin phiên bản 1 chỉ dùng hai byte 2
   //      Thông tin phiên bản 1 chỉ dùng bốn byte 2
   unsigned short phienBan_phan0;   // phân 0 của thông tin phiên bản
   unsigned short phienBan_phan1;   // phân 1 của thông tin phiên bản

   unsigned short maLenhDau;     // mã lệnh đầu trong
   unsigned short rowBytes;
   unsigned char colorPixMap;
   ColorTable colorTable;
   
   unsigned short srcRectTop;    // chũ nhật nguồn trên
   unsigned short srcRectLeft;   // chũ nhật nguồn trái
   unsigned short srcRectBottom; // chũ nhật nguồn dưới
   unsigned short srcRectRight;      // chũ nhật nguồn phải

   unsigned short dstRectTop;    // chũ nhật đích trên
   unsigned short dstRectLeft;   // chũ nhật đích trái
   unsigned short dstRectBottom; // chũ nhật đích dưới
   unsigned short dstRectRight;      // chũ nhật đích phải
   
   unsigned short srcCopy;       // chép nguồn

//   PicSize picSize;
//   PicFrame picFrame;
   unsigned char *anh;           // ảnh BGR
   
} PICT;



PICT docPICT( unsigned char *duLieu );
void chieuThongTin_PICT( PICT *taiNguyenPICT );
