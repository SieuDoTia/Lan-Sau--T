/* WIND.h */
/* 2017.08.30 */


#include <stdio.h>
#include <stdlib.h>
#include "vers.h"


vers doc_vers( unsigned char *duLieu, short id ) {
   
   vers taiNguyen_vers;
   taiNguyen_vers.id = id;
   
   // ---- số phiên bản
   taiNguyen_vers.soPhienBan_soNguyen = *(duLieu++);
   unsigned char phanSo = *(duLieu++);

   taiNguyen_vers.soPhienBan_soThapPhan = phanSo >> 4;
   taiNguyen_vers.soPhienBan_soTramPhan = phanSo & 0xf;
   
   // ---- phát hành/không phát hành
   taiNguyen_vers.phatHanh = *(duLieu++);
   taiNguyen_vers.khongPhatHanh = *(duLieu++);
   
   // ---- quốc gia
   duLieu++;  // byte thì không dùng
   taiNguyen_vers.quocGia = *(duLieu++);
 
   // ---- xâu ngắn
   taiNguyen_vers.beDaiXauNgan = *(duLieu++);

   unsigned chiSo = 0;
   while( chiSo < taiNguyen_vers.beDaiXauNgan ) {
      taiNguyen_vers.xauNgan[chiSo] = *(duLieu++);
      chiSo++;
   }
   taiNguyen_vers.xauNgan[chiSo] = 0x00;

   // ---- xâu dài
   taiNguyen_vers.beDaiXauDai = *(duLieu++);

   chiSo = 0;
   while( chiSo < taiNguyen_vers.beDaiXauDai ) {
      taiNguyen_vers.xauDai[chiSo] = *(duLieu++);
      chiSo++;
   }
   taiNguyen_vers.xauDai[chiSo] = 0x00;
   
   return taiNguyen_vers;
}

void chieuThongTin_vers( vers *taiNguyen_vers ) {
   
   printf( "'vers'  %d\n", taiNguyen_vers->id );
   printf( "   số phiên bản: %d.%d.%d\n",
          taiNguyen_vers->soPhienBan_soNguyen,
          taiNguyen_vers->soPhienBan_soThapPhan,
          taiNguyen_vers->soPhienBan_soTramPhan );
   
   // ----
   if( taiNguyen_vers->phatHanh == 0x20 )
      printf( "   phiên bản đang phát triển   không phát hành: %d    quốc gia %d\n",
             taiNguyen_vers->khongPhatHanh,
             taiNguyen_vers->quocGia );
   else if( taiNguyen_vers->phatHanh == 0x40 )
      printf( "   phiên bản alpha   không phát hành: %d    quốc gia %d\n",
             taiNguyen_vers->khongPhatHanh,
             taiNguyen_vers->quocGia );
   else if( taiNguyen_vers->phatHanh == 0x60 )
      printf( "   phiên bản beta   không phát hành: %d    quốc gia %d\n",
             taiNguyen_vers->khongPhatHanh,
             taiNguyen_vers->quocGia );
   else if( taiNguyen_vers->phatHanh == 0x80 )
      printf( "   phiên bản phát hành   không phát hành: %d    quốc gia %d\n",
             taiNguyen_vers->khongPhatHanh,
             taiNguyen_vers->quocGia );
   else
      printf( "   phiên bản không rõ    không phát hành: %d    quốc gia %d\n",
         taiNguyen_vers->khongPhatHanh,
          taiNguyen_vers->quocGia );

   // ----
   printf( "   xâu ngắn: %s\n   xâu dài: %s\n",
          taiNguyen_vers->xauNgan,
          taiNguyen_vers->xauDai );
}
