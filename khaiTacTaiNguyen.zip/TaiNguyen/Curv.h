/* Curv.h */
/* 2017.09.01 */
/* Chúng tôi đoán toàn bộ này, chưa rõ cấu trúc 'Curv' là gì */

#pragma once

#define kCurv 0x43757276


typedef struct {
   /* đóan */
   unsigned short maSo;
   unsigned int matNa0;
   unsigned int matNa1;
   
}  MatNaKhuc;

typedef struct {
   unsigned char soLuong;  // số lượng khúc trong mạng
   MatNaKhuc matNa[4];
}  MangMatNa;

/* _SICN */
typedef struct {
   
   unsigned char soLuong;  // số lượng bó
   MangMatNa *mangMatNa;
} BoMatNa;

/* 'Curv' */
typedef struct {
   unsigned short soLuongSICN;   // số lượng SICN
   BoMatNa mangBoMatNa[16];  // mạng bó khúcs
} Curv;



Curv docCurv( unsigned char *duLieu, unsigned int beDai );
void chieuThongTin_Curv( Curv *taiNguyenCurv );
